# -*- coding:utf-8 -*-
"""
作者：Guanyueyue
日期：2021年09月17日
"""

import os, time
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import datetime
import humanize


def csv2images(src):
    target_dir = os.getcwd()
    package_name, iphone_info = tets_info(src)

    """
            Args:
                src: csv file, default to perf record csv path
                target_dir: images store dir
            """

    plt.figure(figsize=(19.20, 10.80))
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    data = pd.read_csv(src)
    data['time'] = data['time'].apply(
        lambda x: datetime.datetime.strptime(x,
                                             "%Y-%m-%d %H:%M:%S.%f"))  # time.strftime("%Y/%m/%d/%H/%M/%S", time.localtime())  %Y-%m-%d %H:
    #     #timestr = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    timestr = time.strftime("%Y-%m-%d %H:%M")
    # network
    rx_str = round(data['rxBytes'].sum(), 2)
    tx_str = round(data['txBytes'].sum(), 2)

    plt.subplot(7, 1, 1)
    plt.plot(data['time'], data['rxBytes'], label='all')
    plt.plot(data['time'], data['rxTcpBytes'], 'r--', label='tcp')
    plt.legend()

    plt.title(
        '\n'.join(
            ["Summary", iphone_info, src.split("/")[-1], package_name, timestr,
             'Recv %s KB, Send %s KB' % (rx_str, tx_str)]),
        loc='left')
    plt.gca().xaxis.set_major_formatter(ticker.NullFormatter())

    plt.ylabel('Recv(KB)')
    plt.ylim(ymin=0)

    plt.subplot(7, 1, 2)
    plt.plot(data['time'], data['txBytes'], label='all')
    plt.plot(data['time'], data['txTcpBytes'], 'r--', label='tcp')
    plt.legend()
    # plt.xlabel('Time')
    plt.ylabel('Send(KB)')
    plt.ylim(ymin=0)
    plt.gca().xaxis.set_major_formatter(ticker.NullFormatter())
    # .clf()

    plt.subplot(7, 1, 3)

    plt.plot(data['time'], data['mem'], '-')
    plt.ylabel('mem(MB)')
    plt.gca().xaxis.set_major_formatter(ticker.NullFormatter())

    plt.subplot(7, 1, 4)
    plt.plot(data['time'], data['cpu'], 'r--', label='cpu')  # systemCpu
    plt.plot(data['time'], data['systemCpu'], label='systemCpu')  # systemCpu
    plt.legend()
    plt.ylim(0, max(100, data['cpu'].max()))
    plt.ylabel('CPU')
    plt.ylim(ymin=0)
    plt.gca().xaxis.set_major_formatter(ticker.NullFormatter())

    plt.subplot(7, 1, 5)
    plt.plot(data['time'], data['fps'], '-')
    plt.ylabel('FPS')
    plt.ylim(-1, 60)
    plt.gca().xaxis.set_major_formatter(ticker.NullFormatter())

    plt.subplot(7, 1, 6)
    plt.plot(data['time'], data['level'], '-')
    plt.ylabel('level')
    plt.ylim(0, 110)
    plt.gca().xaxis.set_major_formatter(ticker.NullFormatter())

    plt.subplot(7, 1, 7)
    plt.plot(data['time'], data['batterytem'], '-')
    plt.ylim(0, 100)
    plt.ylabel('BatteryTem')
    plt.xlabel('Time')
    plt.savefig(os.path.join(target_dir, src.split("/")[-1].split('.')[0] + ".png"))


def tets_info(src):
    data = pd.read_csv(src)
    pack = (data['package'][0]).replace(" ", '')
    iphone = (data['iphone_info'][0])
    return [pack, iphone]


if __name__ == '__main__':
    # src = input('请将csv文件拖入窗口，并点击回车！！！！！\n\n')
    # src = '20200113104916.csv'
    src = (os.getcwd() + "/test_data/" + os.listdir((os.getcwd() + "/test_data"))[-1])
    print(src)
    csv2images(src)
    # input(".............................")
